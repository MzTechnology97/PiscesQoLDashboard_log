<?php

### INIT SCRIPT ###

# The init script is run on every page. This also includes pages that are only
#   used for a PHP include function on another page. You can add code here
#   yourself.
# This script can be used for security purposes. I.e. requiring a user to be
#   logged in to view a page.

?>
