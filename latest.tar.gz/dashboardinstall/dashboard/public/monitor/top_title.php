<?php include __DIR__."/init.php"; ?>
<div class="top_title">
    <h1><a href="./">Miner monitor</a></h1>
</div>
