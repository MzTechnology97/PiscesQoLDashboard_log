<?php include __DIR__."/init.php"; ?>
<!-- google font for better styling -->
<link href="https://fonts.googleapis.com/css?family=Maven+Pro:500|Open+Sans" rel="stylesheet">
<!-- jQuery is required for the scripts that retrieve the data -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- main styling -->
<link rel="stylesheet" type="text/css" href="server-monitor.css" />
<!-- responsive web design -->
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<!-- main script -->
<script type="text/javascript" src="server-monitor.js"></script>
