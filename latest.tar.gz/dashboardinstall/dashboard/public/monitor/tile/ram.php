<?php include dirname(__DIR__)."/init.php"; ?>
<h2 class="tile_title">RAM</h2>
<div class="tile_info_container">
    <div class="tile_info_item">
        <span data-output="ram_free" data-output-process>-</span>
        <span class="small_under_title">RAM free</span>
    </div>
</div>
<div class="tile_more_button">
    <a href="./ram/">more info</a>
</div>
