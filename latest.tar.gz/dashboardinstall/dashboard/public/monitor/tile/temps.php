<?php include dirname(__DIR__)."/init.php"; ?>
<h2 class="tile_title">Temperature</h2>
<div class="tile_info_container">
    <div class="tile_info_item">
        <span data-output="temp_cpu">-</span>
        <span class="small_under_title">CPU temperature</span>
    </div>
</div>
<div class="tile_more_button">
    <a href="./temps/">more info</a>
</div>
