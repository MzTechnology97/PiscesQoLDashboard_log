<?php include dirname(__DIR__)."/init.php"; ?>
<h2 class="tile_title">Network</h2>
<div class="tile_info_container">
    <div class="tile_info_item">
        <span data-output="network_connection_type">-</span>
        <span class="small_under_title">Connection type</span>
    </div>
</div>
<div class="tile_more_button">
    <a href="./network/">more info</a>
</div>
