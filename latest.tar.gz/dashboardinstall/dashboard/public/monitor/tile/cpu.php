<?php include dirname(__DIR__)."/init.php"; ?>
<h2 class="tile_title">CPU</h2>
<div class="tile_info_container">
    <div class="tile_info_item">
        <span data-output="cpu_usage_total">-</span>
        <span class="small_under_title">Total CPU usage</span>
    </div>
</div>
<div class="tile_more_button">
    <a href="./cpu/">more info</a>
</div>
