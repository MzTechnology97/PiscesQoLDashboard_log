<?php include dirname(__DIR__)."/init.php"; ?>
<h2 class="tile_title">Storage</h2>
<div class="tile_info_container">
    <div class="tile_info_item">
        <span data-output="storage_free" data-output-process>-</span>
        <span class="small_under_title">Storage free</span>
    </div>
</div>
<div class="tile_more_button">
    <a href="./storage/">more info</a>
</div>
