<?php
clearstatcache();
$info['service'] = trim(file_get_contents('/var/dashboard/services/clean-cache'));
if($_GET['start'])
{
	$info['service'] = trim(file_get_contents('/var/dashboard/services/clean-cache'));

	if($info['service'] == 'stopped')
	{
		$file = fopen('/var/dashboard/services/clean-cache', 'w');
		fwrite($file, 'start');
		fclose($file);

		$file = fopen('/var/dashboard/logs/clean-cache.log', 'w');
		fwrite($file, '');
		fclose($file);

	}
}
?>
<h1>Clear Linux Cache</h1>
<textarea id="log_output" disabled>
<?php
echo "Awaiting start...";
?>
</textarea>
<a title="Start" id="StartCacheClearButton" href="#" onclick="StartCacheClear()">Start</a>


