#!/bin/bash
wget --no-cache https://raw.githubusercontent.com/MzTechnology97/PiscesQoLDashboard_log/main/version -O /var/dashboard/update
